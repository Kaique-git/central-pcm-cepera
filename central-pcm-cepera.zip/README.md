# Central de Sistemas — PCM Cepêra

Portal unificado com **Single Sign-On (SSO)** e **Controle de Acesso Baseado em Função e Usuário (RBAC)** para os 5 aplicativos do Planejamento e Controle de Manutenção (PCM) da Cepera Alimentos.

## 🚀 Aplicativos Integrados

| ID RBAC | Arquivo | Sistema | Coleções Firestore (`pcm-cepera`) |
| :--- | :--- | :--- | :--- |
| `inspecao_rota` | `INSPEÇÃO DE ROTA.html` | **Rotas & Inspeções — 52 Semanas** | `ob_linhas`, `ir_agenda`, `ir_checklists`, `ir_anomalias`, `ir_funcionarios` |
| `matriz_habilidades` | `MATRIZ HABILIDADES.html` | **Matriz & Árvore de Habilidades** | `ir_funcionarios`, `ob_linhas` |
| `agenda_pcm` | `AGENDA-PCM.html` | **Agenda de Manutenção PCM** | `ag_manutencao`, `ag_responsaveis`, `ag_equipes`, `ag_setores` |
| `obsolescencia` | `OBSOLECENCIA.html` | **Gestão Integrada de Ativos & Obsolescência** | `ob_equipamentos`, `ob_linhas` |
| `dashboard_multipet` | `DASHBOARD - MULTIPET.html` | **Dashboard de Produção — Multipets** | `mp_producao` |

## 🔐 Arquitetura SSO & RBAC

- **Login Principal Único (`index.html`)**: Autentica os colaboradores diretamente na coleção `ir_funcionarios` do Firebase (`pcm-cepera`) e propaga a sessão (`cepera_ir_user` e `cepera_central_session`) para todos os 5 módulos sem necessidade de novo login.
- **Delegação Granular de Acessos (RBAC)**:
  - No painel **Controle RBAC & Usuários** (exclusivo para `Admin`), é possível liberar ou bloquear individualmente cada um dos 5 aplicativos para cada colaborador através de chaves interativas em tempo real (`apps_permitidos` no documento do usuário em `ir_funcionarios`).
  - As páginas individuais possuem proteção de sessão e RBAC: caso um usuário tente acessar diretamente a URL de um aplicativo não autorizado ou sem sessão ativa, é redirecionado automaticamente para `index.html`.
- **Workspace Integrado**: Permite abrir qualquer aplicativo dentro da própria Central com barra superior de alternância rápida entre os sistemas permitidos para o usuário, ou abrir em nova guia.
